import React, { useState } from 'react'

function Add({onadd}) {
  const [name,setName] = useState("")
  const [email,setemail] = useState("")

  return (
    <div>

      <h1>Add user</h1>

<form onSubmit={(e)=>{e.preventDefault()}}>
 
   <div>
   <label className="col-sm-2 col-form-label">Name</label>
   <input type="text" value={name} onChange={(e)=>{setName(e.target.value)}} className="border border-1" id="inputEmail3"/>
   </div> 
   <div>
   <label  className="col-sm-2 col-form-label">Email</label>
   <input type="email" value={email} onChange={(e)=>{setemail(e.target.value)}} className="border border-1" id="inputPassword3"/>
    </div> 
  <button type="submit" className="btn btn-primary m-2 p-2"  onClick={()=>{onadd(name,email)}}>Add User</button>
</form>
     
    </div>
  )
}

export default Add
