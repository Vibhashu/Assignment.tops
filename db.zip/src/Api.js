export const FetchQuestions = () => {
    return fetch('http://localhost:8000/data').then(res => res.json());
  };
  