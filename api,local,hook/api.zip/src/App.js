import './App.css';
import Home from './Home';
import '../node_modules/bootstrap/dist/css/bootstrap.css'


function App() {
  return (
    <div className="App">
      <h1>JSON CRUD</h1>
  <Home/>
     
    </div>
  );
}

export default App;
