import logo from './logo.svg';
import './App.css';
import Home from './Home';
import '../node_modules/bootstrap/dist/css/bootstrap.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Add from './Add';
import Edit from './Edit';

function App() {
  return (
    <div className="App">
      <h1>JSON CRUD</h1>
     <BrowserRouter>
     <Routes>
      <Route path='/' element={ <Home/>}></Route>
      <Route path='/add' element={ <Add/>}></Route>
      <Route path='/edit/:id' element={ <Edit/>}></Route>

     </Routes>
     </BrowserRouter>
    </div>
  );
}

export default App;
