import logo from './logo.svg';
import './App.css';
import Local from './Local';

function App() {
  return (
    <div className="App">
     <Local/>
    </div>
  );
}

export default App;
