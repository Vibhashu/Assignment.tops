import React, { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'

function Edit() {
    const [name, setname] = useState("");
    const [email, setemail] = useState("");

    const {id} = useParams();

    console.log(id)

    let navi = useNavigate();

    useEffect(()=>{
        fetch('http://localhost:5001/user/'+id)
        .then((res)=>{ return res.json()})
        .then((data)=>{
             setname(data.name)
             setemail(data.email)
        })
    },[])
      const handleAdd = (e)=>{
        e.preventDefault();
        fetch('http://localhost:5001/user/'+id,{
            method:"put",
            headers:{"content-type":"application/json"},
            body:JSON.stringify({name ,email})
        })
        .then((res)=>{
            if(res)
            {
                navi('/')
            }
        })
      }
  return (
    <div>
      <div className="container">
        <div className="row justify-content-center text-start">
          <div className="col-xl-8">
            <div>
              <h3>Edit Users Details</h3>
              <Link to="/" className="btn btn-warning my-3">
              Home
              </Link>
            </div>

            <div>
              <form onSubmit={handleAdd}>
                <div>
                  <label>Name: </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => {
                      setname(e.target.value);
                    }}
                    className="form-control"
                  />
                </div>
                <div>
                    <label>Email: </label>
                    <input
                    type="text"
                    value={email}
                    onChange={(e) => {
                      setemail(e.target.value);
                    }}
                    className="form-control"
                  />
                </div>
                <div>
                  <input type="submit" className="btn btn-primary my-2" value={"Update"} />
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Edit
