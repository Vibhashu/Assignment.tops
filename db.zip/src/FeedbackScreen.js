import React from 'react';

const FeedbackScreen = ({ questions, answers }) => {
  const score = answers.filter(ans => ans.correct).length;

  return (
    <div className="feedback">
      <h2>Your Score: {score} / {questions.length}</h2>

      {questions.map((q, idx) => {
        const userAnswer = answers[idx].selectedWords;
        const isCorrect = answers[idx].correct;
        return (
          <div key={idx} className={`feedback-item ${isCorrect ? 'correct' : 'incorrect'}`}>
            <p><strong>Q{idx + 1}:</strong> {q.sentence.replace(/___/g, () => `[${userAnswer.shift() || ''}]`)}</p>
            {!isCorrect && (
              <p>✅ Correct: {q.correctAnswer.join(', ')}</p>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default FeedbackScreen;
