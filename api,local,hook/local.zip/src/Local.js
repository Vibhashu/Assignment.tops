import React from 'react'

function Local() {

    function Save()
    {

      let  contactlist = JSON.parse(localStorage.getItem('listItam')) ??  [];   
        

        let id ;

        contactlist.length !==0 ? contactlist.findLast((user)=> id = user.id) : id = 0;

        const user = {
            id: id+1,
            name:document.getElementById("name").value,
            age:document.getElementById("age").value,
            address:document.getElementById("address").value,
            phone:document.getElementById("phone").value,
        }

     contactlist.push(user)

        localStorage.setItem('listItam',JSON.stringify(contactlist))

    }
  return (
    <div>

    <form>
       <div>
        <label>Name</label>
        <input id="name" type="text" placeholder="Name"/>
       </div>

       <div>
        <label>Age</label>
        <input id="age" type="number" placeholder="Age"/>
       </div>
       <div>
        <label>Address</label>
        <textarea id="address" placeholder="Address"></textarea>
       </div>
       <div>
        <label>Phone</label>
        <input id="phone" type="number" placeholder="Phone"/>
       </div>
       <div>
       
        <input  type="reset" />
       </div>
       <div>
       
        <input type="button" value="Save" onClick={Save} />
       </div>
    </form>

       

      
    </div>
  )
}

export default Local
