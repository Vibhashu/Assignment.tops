import React, { useState } from 'react'

function Edit({getuser,getuserid,getEditedObj}) {

  

  return (
    <>
     <table className='table'>
        <thead className='table-dark'>
          <tr>
            <th>ID</th>
            <th>NAME</th>
            <th>EMAIL</th>
            <th>ACTION</th>
          </tr>
        </thead>
        <tbody>

    {getuser  && getuser.map((user)=>(
    

      <tr key={user.id}>
        <td>{user.id}</td>
        <td>{user.name}</td>
        <td>{user.email}</td>
        <td>
          <Button
           obj={user}
           ondelete={getuserid}
           onedit={getEditedObj}
          ></Button>
        </td>
      </tr>

  
    ))}
   </tbody>
     </table>
      
    </>
  )
}
function Button({obj,ondelete,onedit})
{
console.log(obj)
  const [show,setshow] = useState(false);
  
  
  let btns;

  if(show)
  {

   
     btns=<>
      <label>NAME: </label><input type='text' className='border border-1 rounded' value={obj.name} 
         onChange={
            (e)=>{
              onedit({
                    ...obj,
                    name:e.target.value
                })
            }
         }/>
      <label>EMAIL: </label><input type='email' className='border border-1 rounded' value={obj.email} 
         onChange={
            (e)=>{
              onedit({
                    ...obj,
                    email:e.target.value
                })
            }
         }/> 
     <button onClick={()=>{setshow(false)}} className='btn btn-success m-2' >Save</button>    
    
     </>
   

  }else
  {

    btns=<>
    <button onClick={()=>{setshow(true)}} className='btn btn-success m-2'>Edit</button>
    </>

  }

  return(
    <>
    {btns}
      <button className='btn btn-danger' onClick={()=>{ondelete(obj.id)}}>Delete</button>
      </>
  )

}

export default Edit
