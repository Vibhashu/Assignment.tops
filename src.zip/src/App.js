import logo from './logo.svg';
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.css';
import Home from './Home';

function App() {
  return (
    <div className="App">
    <Home/>
    </div>
  );
}

export default App;
