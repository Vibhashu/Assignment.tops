import React, { useEffect, useState } from 'react';

const SentenceQuestion = ({ question, onSubmit }) => {
  const [selectedWords, setSelectedWords] = useState(Array(question.blanks).fill(null));
  const [timer, setTimer] = useState(30);

  useEffect(() => {
    const interval = setInterval(() => {
      setTimer(t => t - 1);
    }, 1000);

    if (timer === 0) {
      handleSubmit();
    }

    return () => clearInterval(interval);
  }, [timer]);

  const handleWordClick = (word) => {
    const index = selectedWords.findIndex(w => w === null);
    if (index !== -1 && !selectedWords.includes(word)) {
      const updated = [...selectedWords];
      updated[index] = word;
      setSelectedWords(updated);
    }
  };

  const handleBlankClick = (index) => {
    const updated = [...selectedWords];
    updated[index] = null;
    setSelectedWords(updated);
  };

  const handleSubmit = () => {
    const isCorrect = JSON.stringify(selectedWords) === JSON.stringify(question.correctAnswer);
    onSubmit(selectedWords, isCorrect);
  };

  const renderSentence = () => {
    const parts = question.sentence.split('___');
    return parts.map((part, idx) => (
      <span key={idx}>
        {part}
        {idx < question.blanks && (
          <span
            className="blank"
            onClick={() => handleBlankClick(idx)}
          >
            {selectedWords[idx] || '______'}
          </span>
        )}
      </span>
    ));
  };

  return (
    <div className="question-container">
      <div className="timer">⏱ {timer}s</div>
      <div className="sentence">{renderSentence()}</div>

      <div className="options">
        {question.options.map((word, i) => (
          <button
            key={i}
            className={`option-btn ${selectedWords.includes(word) ? 'disabled' : ''}`}
            onClick={() => handleWordClick(word)}
            disabled={selectedWords.includes(word)}
          >
            {word}
          </button>
        ))}
      </div>

      <button
        className="next-btn"
        onClick={handleSubmit}
        disabled={selectedWords.includes(null)}
      >
        Next
      </button>
    </div>
  );
};

export default SentenceQuestion;
