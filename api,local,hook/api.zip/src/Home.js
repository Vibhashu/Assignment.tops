import React, { useEffect, useState } from 'react'


let index = 11

function StateDummyCrud()


{
   useEffect(()=>{
     fetch('https://jsonplaceholder.typicode.com/users')
     .then((res)=>{return res.json()})
     .then((data)=>{
        setArr(data)
     })
   },[])
      
      const [data,setData] = useState("")
      const [data1,setData1] = useState("")



      const [arr,setArr] = useState([])

      
     

      const handleAdd = (name,email)=>{
          
          setArr(
            [...arr,
                {"id":index++,"name":name,"email":email}
            ]
          )
      }


      const handleedit = (data , email)=>{
         setArr (arr.map((obj)=>{
            console.log(obj)
             if(obj.id == data.id)
             {
                return data
             }
             else
             {
                return obj
             }
         }))
        }

       const handleDelete =(id)=>{
         setArr(arr.filter((value)=>{
              return value.id !== id
         }))
       }
  
      
      
    return(
        <>
        
               <div className='container'>
            <div className='row justify-content-center'>
                <div className='col-xl-6'>
                    <div>
                        <h3>User Details</h3>
                        <h2 className='pb-5'>ADD USER</h2>
                      Name:   <input type='text' value={data} onChange={(e)=>{setData(e.target.value)}}></input><br/>
                       Email:  <input className='m-3' type='email' value={data1} onChange={(e)=>{setData1(e.target.value)}}></input><br/>
                         <button className='btn btn-info' onClick={()=>{handleAdd(data,data1)}}>Add</button>
                        </div>
                    <div>
                        <table className='table'>
                            <thead className='table-dark'>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                               {arr.map((obj)=>(
                                 <tr key={obj.id}>
                                 <td>{obj.id}</td>
                                 <td>{obj.name}</td>
                                 <td>{obj.email}</td>
                                 <td>
                                 <Buttons arraydata={obj} editdata={handleedit} deleteData={handleDelete}></Buttons>
                                 </td>
                             </tr>
                               ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        </>
    )
}

function Buttons({arraydata , editdata , deleteData}) {

    const [show,setShow] = useState(true)


    let btn;

    if(show)
    {
           btn = <>
            <button onClick={()=>{setShow(false)}} className='btn btn-success mx-3 my-2'>Edit</button>
           </>
    }
    else
    {
        btn =  <>
       Name: <input type='text' value={arraydata.name} onChange={(e)=>{
             editdata(
                {...arraydata,
                    name:e.target.value
                }
             )
        }} ></input><br/>

       Email:      <input type='text' value={arraydata.email} onChange={(e)=>{
             editdata(
                {...arraydata,
                    email:e.target.value
                }
             )
        }} ></input>
        
        <button onClick={()=>{setShow(true)}} className='btn btn-warning mx-3 my-2'>Save</button>
        </>
    }
  return (
   <>
        
          
        {btn}
       <button className='btn btn-danger' onClick={()=>{
        
           deleteData(arraydata.id)
       }}>Delete</button>
       
      
   </>
  )
}

export default StateDummyCrud