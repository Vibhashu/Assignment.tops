import React, { useState } from 'react'
import Edit from './Edit'
import Add from './Add'
let index = 4;

const users = [
  {id:1,name:"jaydeep",email:"jaydeep@gmail.com"},
  {id:2,name:"mohit",email:"mohit@gmail.com"},
  {id:3,name:"aniket",email:"aniket@gmail.com"}
]


  
  function Home() {
    const [user,setuser] = useState(users)


    const adduser = (para)=>{
      setuser([
          ...user,
          {id:index++,name:para}
      ])
  
  }
  const handleDelete = (para)=>{ 
   setuser( user.filter((obj)=>{
    return obj.id !== para
}))
}
  const handleEdit = (para)=>{

    setuser(user && user.map((obj)=>{
        if(obj.id == para.id)
        {
            return para;
        }
        else 
        {
            return obj;
        }
    }))
}
  return (
    <div>
      <Add onadd={adduser}/>

      <Edit getuser={user}
       getuserid={handleDelete}
       getEditedObj={handleEdit}/>
      
    </div>
  )
}

export default Home
