import React, { useEffect, useState } from 'react';
import SentenceQuestion from './SentenceQuestion';
import FeedbackScreen from './FeedbackScreen';
// import { FetchQuestions } from './Api';
import './App.css';

const App = () => {
  const [questions, setQuestions] = useState([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [showFeedback, setShowFeedback] = useState(false);

  useEffect(() => {
    fetch('http://localhost:8000/data').then(res => res.json()).then(data => {
      setQuestions(data);
    });
  }, []);

  const handleAnswerSubmit = (selectedWords, correct) => {
    setAnswers(prev => [...prev, { selectedWords, correct }]);

    if (currentIdx + 1 < questions.length) {
      setCurrentIdx(prev => prev + 1);
    } else {
      setShowFeedback(true);
    }
  };

  return (
    <div className="app">
      {showFeedback ? (
        <FeedbackScreen questions={questions} answers={answers} />
      ) : (
        questions.length > 0 && (
          <SentenceQuestion
            key={currentIdx}
            question={questions[currentIdx]}
            onSubmit={handleAnswerSubmit}
          />
        )
      )}
    </div>
  );
};

export default App;
